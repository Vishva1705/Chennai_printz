﻿var gStrIpVal = "http://192.168.29.204:5555/";

/*var gStrIpVal = "http://192.168.29.157:7121/";*/

